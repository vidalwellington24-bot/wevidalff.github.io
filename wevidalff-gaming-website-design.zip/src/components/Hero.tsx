import { ChevronDown, Zap, Shield } from 'lucide-react';

export default function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden scanline">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img 
          src="/images/hero-bg.jpg" 
          alt="" 
          className="w-full h-full object-cover opacity-30"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark-bg via-dark-bg/70 to-dark-bg" />
        <div className="absolute inset-0 bg-gradient-to-r from-neon-red/5 via-transparent to-neon-red/5" />
      </div>

      {/* Grid overlay */}
      <div className="absolute inset-0 grid-bg opacity-40" />

      {/* Diagonal stripes */}
      <div className="absolute inset-0 stripe-pattern opacity-50" />

      {/* Red corner accents */}
      <div className="absolute top-0 left-0 w-32 h-32 border-l-2 border-t-2 border-neon-red/30" />
      <div className="absolute top-0 right-0 w-32 h-32 border-r-2 border-t-2 border-neon-red/30" />
      <div className="absolute bottom-0 left-0 w-32 h-32 border-l-2 border-b-2 border-neon-red/30" />
      <div className="absolute bottom-0 right-0 w-32 h-32 border-r-2 border-b-2 border-neon-red/30" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-5xl mx-auto">
        {/* Top badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-neon-red/10 border border-neon-red/30 rounded-full text-neon-red text-xs sm:text-sm font-medium mb-6 fade-in-up">
          <Zap size={14} className="fill-neon-red" />
          REPÚBLICA DOMINICANA 🇩🇴
          <span className="w-1 h-1 bg-neon-red rounded-full" />
          100K SUSCRIPTORES
        </div>

        {/* Main heading */}
        <h1 className="font-heading font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-tight mb-2 glitch-text">
          <span className="gradient-text">WEVIDALFF</span>
        </h1>
        <div className="red-line w-32 mx-auto my-4" />
        <h2 className="font-heading font-semibold text-sm sm:text-base md:text-lg lg:text-xl text-gray-300 tracking-widest uppercase mb-6">
          Dominando el Juego y Optimizando tu Mundo
        </h2>

        {/* Description */}
        <p className="text-gray-400 text-sm sm:text-base max-w-2xl mx-auto mb-8 leading-relaxed">
          Creador de contenido especializado en <span className="text-neon-red font-semibold">Free Fire</span> (historias y misterios) 
          y <span className="text-minecraft-green font-semibold">Minecraft Bedrock</span> (comandos técnicos). 
          Grabación con calidad profesional usando <span className="text-white font-semibold">Casco Pro</span>.
        </p>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-10">
          <div className="text-center">
            <div className="font-heading font-black text-2xl sm:text-3xl text-neon-red neon-text-subtle">100K+</div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">Suscriptores</div>
          </div>
          <div className="w-px h-12 bg-dark-border hidden sm:block" />
          <div className="text-center">
            <div className="font-heading font-black text-2xl sm:text-3xl text-white">2</div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">Canales</div>
          </div>
          <div className="w-px h-12 bg-dark-border hidden sm:block" />
          <div className="text-center">
            <div className="font-heading font-black text-2xl sm:text-3xl text-bermuda-teal">🇩🇴</div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">Dominicano</div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#misterios"
            className="group relative px-8 py-3 bg-neon-red text-white font-bold rounded text-sm uppercase tracking-wider overflow-hidden transition-all hover:shadow-[0_0_30px_#ff004060]"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Shield size={16} />
              Explorar Misterios
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-neon-red to-red-600 opacity-0 group-hover:opacity-100 transition-opacity" />
          </a>
          <a
            href="#recursos"
            className="px-8 py-3 border border-neon-red/40 text-neon-red font-bold rounded text-sm uppercase tracking-wider hover:bg-neon-red/10 transition-all"
          >
            Recursos Pro
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500">
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <ChevronDown size={20} className="animate-bounce" />
      </div>
    </section>
  );
}

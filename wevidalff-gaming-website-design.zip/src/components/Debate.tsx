import { useState } from 'react';
import { ThumbsUp, MessageCircle, Flame, Send, Swords } from 'lucide-react';

interface VoteState {
  freefire: number;
  pubg: number;
  userVote: 'freefire' | 'pubg' | null;
}

interface Comment {
  id: number;
  user: string;
  text: string;
  side: 'freefire' | 'pubg' | 'neutral';
  time: string;
  likes: number;
}

const debateTopics = [
  '¿Cuál tiene mejor modo Battle Royale?',
  '¿Mejor optimización en móviles de gama baja?',
  '¿Mejor comunidad y eventos?',
  '¿Mejor sistema de armas?',
];

const defaultComments: Comment[] = [
  { id: 1, user: 'DragonSlayer99', text: 'Free Fire tiene la mejor comunidad, los eventos son más accesibles para todos.', side: 'freefire', time: 'hace 2h', likes: 24 },
  { id: 2, user: 'TacticalPro', text: 'PUBG tiene mejor realismo en las armas y el mapa es más grande, eso es innegable.', side: 'pubg', time: 'hace 1h', likes: 18 },
  { id: 3, user: 'MobileGamer_RD', text: 'En gama baja, Free Fire gana por goleada. Se nota la diferencia de optimización.', side: 'freefire', time: 'hace 45m', likes: 31 },
  { id: 4, user: 'ProSniper_X', text: 'Los gráficos de PUBG son superiores, pero Free Fire es más divertido y dinámico.', side: 'neutral', time: 'hace 30m', likes: 15 },
  { id: 5, user: 'WEvidalFan', text: 'WEvidalFF demuestra que Free Fire tiene los mejores misterios y lore del juego 🔥', side: 'freefire', time: 'hace 15m', likes: 42 },
];

export default function Debate() {
  const [votes, setVotes] = useState<VoteState>({
    freefire: 1247,
    pubg: 983,
    userVote: null,
  });
  const [comments, setComments] = useState<Comment[]>(defaultComments);
  const [newComment, setNewComment] = useState('');
  const [commentSide, setCommentSide] = useState<'freefire' | 'pubg' | 'neutral'>('neutral');

  const totalVotes = votes.freefire + votes.pubg;
  const ffPercent = Math.round((votes.freefire / totalVotes) * 100);
  const pubgPercent = 100 - ffPercent;

  const handleVote = (side: 'freefire' | 'pubg') => {
    if (votes.userVote === side) return;
    
    setVotes(prev => {
      const newVotes = { ...prev };
      // Remove previous vote
      if (prev.userVote) {
        newVotes[prev.userVote] -= 1;
      }
      // Add new vote
      newVotes[side] += 1;
      newVotes.userVote = side;
      return newVotes;
    });
  };

  const handleSubmitComment = () => {
    if (!newComment.trim()) return;
    const comment: Comment = {
      id: Date.now(),
      user: 'Visitante',
      text: newComment.trim(),
      side: commentSide,
      time: 'ahora',
      likes: 0,
    };
    setComments([comment, ...comments]);
    setNewComment('');
  };

  return (
    <section id="debate" className="relative py-20 sm:py-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark-bg" />
      <div className="absolute inset-0 grid-bg opacity-20" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-neon-red/10 border border-neon-red/20 rounded-full text-neon-red text-xs font-medium mb-4">
            <Swords size={12} />
            ZONA DE DEBATE
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-4xl md:text-5xl mb-4">
            <span className="text-neon-red">FREE FIRE</span>
            <span className="text-gray-500 mx-3">VS</span>
            <span className="text-bermuda-teal">PUBG</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto">
            ¿Cuál es el mejor? Tu opinión cuenta. Vota y debate con la comunidad.
          </p>
          <div className="red-line w-24 mx-auto mt-4" />
        </div>

        {/* Voting section */}
        <div className="bg-dark-card border border-dark-border rounded-2xl p-4 sm:p-6 mb-8 neon-border">
          {/* Vote buttons */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <button
              onClick={() => handleVote('freefire')}
              disabled={votes.userVote === 'freefire'}
              className={`vote-btn relative overflow-hidden rounded-xl p-4 sm:p-6 text-center transition-all ${
                votes.userVote === 'freefire'
                  ? 'bg-neon-red/20 border-2 border-neon-red shadow-[0_0_20px_#ff004040]'
                  : 'bg-dark-surface border-2 border-dark-border hover:border-neon-red/50'
              }`}
            >
              <div className="text-3xl sm:text-4xl mb-2">🔥</div>
              <h3 className="font-heading font-bold text-lg sm:text-xl text-white">FREE FIRE</h3>
              <p className="text-neon-red font-heading font-bold text-2xl sm:text-3xl mt-2">{ffPercent}%</p>
              <div className="flex items-center justify-center gap-1 mt-2 text-xs text-gray-400">
                <ThumbsUp size={12} />
                {votes.freefire.toLocaleString()} votos
              </div>
            </button>

            <button
              onClick={() => handleVote('pubg')}
              disabled={votes.userVote === 'pubg'}
              className={`vote-btn relative overflow-hidden rounded-xl p-4 sm:p-6 text-center transition-all ${
                votes.userVote === 'pubg'
                  ? 'bg-bermuda-teal/20 border-2 border-bermuda-teal shadow-[0_0_20px_#00e5ff40]'
                  : 'bg-dark-surface border-2 border-dark-border hover:border-bermuda-teal/50'
              }`}
            >
              <div className="text-3xl sm:text-4xl mb-2">🎯</div>
              <h3 className="font-heading font-bold text-lg sm:text-xl text-white">PUBG</h3>
              <p className="text-bermuda-teal font-heading font-bold text-2xl sm:text-3xl mt-2">{pubgPercent}%</p>
              <div className="flex items-center justify-center gap-1 mt-2 text-xs text-gray-400">
                <ThumbsUp size={12} />
                {votes.pubg.toLocaleString()} votos
              </div>
            </button>
          </div>

          {/* Progress bar */}
          <div className="relative h-3 bg-dark-surface rounded-full overflow-hidden">
            <div 
              className="absolute left-0 top-0 h-full bg-gradient-to-r from-neon-red to-red-500 rounded-full transition-all duration-700"
              style={{ width: `${ffPercent}%` }}
            />
            <div 
              className="absolute right-0 top-0 h-full bg-gradient-to-l from-bermuda-teal to-cyan-600 rounded-full transition-all duration-700"
              style={{ width: `${pubgPercent}%` }}
            />
          </div>
          <div className="flex justify-between mt-2 text-[10px] text-gray-600">
            <span>🔥 Free Fire {ffPercent}%</span>
            <span>{totalVotes.toLocaleString()} votos totales</span>
            <span>{pubgPercent}% PUBG 🎯</span>
          </div>
        </div>

        {/* Debate topics */}
        <div className="mb-8">
          <h3 className="font-heading font-bold text-sm text-gray-400 mb-3 flex items-center gap-2">
            <Flame size={14} className="text-neon-red" />
            TEMAS EN DEBATE
          </h3>
          <div className="grid sm:grid-cols-2 gap-2">
            {debateTopics.map((topic, i) => (
              <div key={i} className="bg-dark-card border border-dark-border rounded-lg px-4 py-3 text-sm text-gray-300 card-hover">
                <span className="text-neon-red mr-2 font-bold">#{i + 1}</span>
                {topic}
              </div>
            ))}
          </div>
        </div>

        {/* Comments section */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-4 sm:p-6">
          <h3 className="font-heading font-bold text-sm text-white mb-4 flex items-center gap-2">
            <MessageCircle size={16} className="text-neon-red" />
            OPINIONES DE LA COMUNIDAD
            <span className="ml-auto text-[10px] text-gray-600 font-normal">{comments.length} comentarios</span>
          </h3>

          {/* Comment form */}
          <div className="mb-6 pb-6 border-b border-dark-border">
            <div className="flex gap-2 mb-3">
              {(['freefire', 'neutral', 'pubg'] as const).map((side) => (
                <button
                  key={side}
                  onClick={() => setCommentSide(side)}
                  className={`px-3 py-1 rounded text-[11px] font-medium transition-all ${
                    commentSide === side
                      ? side === 'freefire'
                        ? 'bg-neon-red/20 text-neon-red border border-neon-red/30'
                        : side === 'pubg'
                        ? 'bg-bermuda-teal/20 text-bermuda-teal border border-bermuda-teal/30'
                        : 'bg-gray-500/20 text-gray-300 border border-gray-500/30'
                      : 'bg-dark-surface text-gray-600 border border-dark-border'
                  }`}
                >
                  {side === 'freefire' ? '🔥 FF' : side === 'pubg' ? '🎯 PUBG' : '⚖️ Neutral'}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSubmitComment()}
                placeholder="Escribe tu opinión..."
                className="flex-1 bg-dark-surface border border-dark-border rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-neon-red/50 transition-colors"
              />
              <button
                onClick={handleSubmitComment}
                disabled={!newComment.trim()}
                className="px-4 py-2.5 bg-neon-red text-white rounded-lg hover:shadow-[0_0_15px_#ff004040] transition-all disabled:opacity-30 disabled:cursor-not-allowed active:scale-95"
              >
                <Send size={16} />
              </button>
            </div>
          </div>

          {/* Comments list */}
          <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
            {comments.map((comment) => (
              <div key={comment.id} className="flex gap-3 group">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  comment.side === 'freefire'
                    ? 'bg-neon-red/20 text-neon-red'
                    : comment.side === 'pubg'
                    ? 'bg-bermuda-teal/20 text-bermuda-teal'
                    : 'bg-gray-500/20 text-gray-400'
                }`}>
                  {comment.user.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">{comment.user}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                      comment.side === 'freefire'
                        ? 'bg-neon-red/10 text-neon-red'
                        : comment.side === 'pubg'
                        ? 'bg-bermuda-teal/10 text-bermuda-teal'
                        : 'bg-gray-500/10 text-gray-500'
                    }`}>
                      {comment.side === 'freefire' ? 'FF' : comment.side === 'pubg' ? 'PUBG' : 'Neutral'}
                    </span>
                    <span className="text-[10px] text-gray-600">{comment.time}</span>
                  </div>
                  <p className="text-gray-400 text-sm mt-1 leading-relaxed">{comment.text}</p>
                  <button className="flex items-center gap-1 mt-1.5 text-gray-600 hover:text-neon-red text-[11px] transition-colors">
                    <ThumbsUp size={10} />
                    {comment.likes}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

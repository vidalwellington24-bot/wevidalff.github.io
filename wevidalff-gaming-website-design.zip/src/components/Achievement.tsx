import { useEffect, useState, useRef } from 'react';
import { Trophy, Star, Award } from 'lucide-react';

function AnimatedCounter({ target, suffix = '' }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [isVisible, target]);

  return <div ref={ref}>{count.toLocaleString()}{suffix}</div>;
}

export default function Achievement() {
  return (
    <section id="logro" className="relative py-20 sm:py-28 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-dark-bg via-dark-surface to-dark-bg" />
      <div className="absolute inset-0 grid-bg opacity-30" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-neon-red/10 border border-neon-red/20 rounded-full text-neon-red text-xs font-medium mb-4">
            <Trophy size={12} className="fill-neon-red" />
            LOGRO DESBLOQUEADO
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-4xl md:text-5xl mb-4">
            <span className="gradient-text">PLACA DE PLATA</span>
          </h2>
          <div className="red-line w-24 mx-auto" />
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Silver Button Image */}
          <div className="flex justify-center">
            <div className="relative group">
              {/* Glow effect behind */}
              <div className="absolute -inset-4 bg-gradient-to-r from-neon-red/20 via-neon-red/10 to-neon-red/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative bg-dark-card border border-dark-border rounded-2xl p-6 sm:p-8 neon-border pulse-glow">
                <img 
                  src="/images/silver-button.png" 
                  alt="YouTube Silver Play Button 100K"
                  className="w-full max-w-sm mx-auto float-animation"
                  loading="lazy"
                />
                
                {/* Corner decorations */}
                <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-neon-red/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-neon-red/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-neon-red/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-neon-red/50" />
              </div>
            </div>
          </div>

          {/* Stats and info */}
          <div className="space-y-6">
            <div className="bg-dark-card border border-dark-border rounded-xl p-6 neon-border card-hover">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-neon-red/10 rounded-lg flex items-center justify-center">
                  <Award size={20} className="text-neon-red" />
                </div>
                <h3 className="font-heading font-bold text-lg">Milestone</h3>
              </div>
              <div className="font-heading font-black text-5xl sm:text-6xl text-neon-red neon-text-subtle">
                <AnimatedCounter target={100000} />
              </div>
              <p className="text-gray-400 text-sm mt-2">Suscriptores en YouTube</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-dark-card border border-dark-border rounded-xl p-4 text-center card-hover">
                <Star size={20} className="text-yellow-500 mx-auto mb-2 fill-yellow-500" />
                <div className="font-heading font-bold text-xl text-white">
                  <AnimatedCounter target={100} suffix="+" />
                </div>
                <p className="text-gray-500 text-xs mt-1">Videos</p>
              </div>
              <div className="bg-dark-card border border-dark-border rounded-xl p-4 text-center card-hover">
                <Trophy size={20} className="text-neon-red mx-auto mb-2" />
                <div className="font-heading font-bold text-xl text-white">
                  <AnimatedCounter target={2} />
                </div>
                <p className="text-gray-500 text-xs mt-1">Canales</p>
              </div>
            </div>

            <div className="bg-dark-card border border-neon-red/20 rounded-xl p-4">
              <p className="text-gray-300 text-sm leading-relaxed">
                <span className="text-neon-red font-bold">"</span>
                Desde República Dominicana para el mundo. Cada suscriptor es parte de esta comunidad 
                que ama los misterios de Free Fire y la técnica de Minecraft. 
                <span className="text-neon-red font-bold">"</span>
              </p>
              <p className="text-neon-red text-xs font-medium mt-2">— WEvidalFF</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

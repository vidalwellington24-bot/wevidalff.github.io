import { Heart, Mail, ExternalLink } from 'lucide-react';

function YoutubeIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
    </svg>
  );
}

export default function Footer() {
  return (
    <footer className="relative py-12 sm:py-16 border-t border-dark-border">
      <div className="absolute inset-0 bg-dark-bg" />
      <div className="absolute inset-0 grid-bg opacity-10" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 bg-neon-red rounded flex items-center justify-center font-heading font-black text-sm text-white">
                W
              </div>
              <span className="font-heading font-bold text-lg neon-text-subtle">WEvidalFF</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed">
              Creador de contenido desde República Dominicana. Especializado en Free Fire y Minecraft Bedrock.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Navegación</h4>
            <ul className="space-y-2">
              {[
                { href: '#inicio', label: 'Inicio' },
                { href: '#logro', label: '100K Achievement' },
                { href: '#misterios', label: 'Misterios de Bermuda' },
                { href: '#recursos', label: 'Recursos Pro' },
                { href: '#debate', label: 'FF vs PUBG' },
              ].map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-gray-500 text-sm hover:text-neon-red transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* YouTube Channels */}
          <div>
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Canales</h4>
            <div className="space-y-3">
              <a
                href="https://youtube.com/@WEvidalFF"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-500 text-sm hover:text-neon-red transition-colors group"
              >
                <YoutubeIcon size={14} />
                <span>WEvidalFF (Principal)</span>
                <ExternalLink size={10} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
              <a
                href="https://youtube.com/@WEvidalFF"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-500 text-sm hover:text-neon-red transition-colors group"
              >
                <YoutubeIcon size={14} />
                <span>Canal Secundario</span>
                <ExternalLink size={10} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>
          </div>

          {/* Equipment */}
          <div>
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Equipamiento</h4>
            <div className="space-y-2 text-sm text-gray-500">
              <p>🎙️ Grabación: Casco Pro</p>
              <p>📱 Mobile Gaming</p>
              <p>🎮 Free Fire & Minecraft</p>
              <p>📍 Rep. Dominicana 🇩🇴</p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-dark-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} WEvidalFF. Todos los derechos reservados.
          </p>
          <p className="flex items-center gap-1 text-gray-600 text-xs">
            Hecho con <Heart size={12} className="text-neon-red fill-neon-red" /> desde República Dominicana
          </p>
          <div className="flex items-center gap-3">
            <a href="mailto:contacto@wevidalff.com" className="text-gray-600 hover:text-neon-red transition-colors">
              <Mail size={16} />
            </a>
            <a href="https://youtube.com/@WEvidalFF" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-neon-red transition-colors">
              <YoutubeIcon size={16} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

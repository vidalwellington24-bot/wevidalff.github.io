import { useState, useEffect } from 'react';
import { Menu, X, ChevronUp } from 'lucide-react';

function YoutubeIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
    </svg>
  );
}

const navLinks = [
  { href: '#inicio', label: 'Inicio' },
  { href: '#logro', label: '100K' },
  { href: '#misterios', label: 'Misterios' },
  { href: '#recursos', label: 'Recursos Pro' },
  { href: '#debate', label: 'Debate' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      setShowTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-dark-bg/95 backdrop-blur-md border-b border-neon-red/20 shadow-[0_2px_20px_rgba(255,0,64,0.1)]' 
          : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a href="#inicio" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-neon-red rounded flex items-center justify-center font-heading font-black text-sm text-white group-hover:shadow-[0_0_15px_#ff0040] transition-shadow">
                W
              </div>
              <span className="font-heading font-bold text-lg tracking-wider neon-text-subtle group-hover:neon-text transition-all">
                WEvidalFF
              </span>
            </a>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="px-3 py-2 text-sm font-medium text-gray-300 hover:text-neon-red transition-colors relative group"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-neon-red transition-all duration-300 group-hover:w-full" />
                </a>
              ))}
              <div className="w-px h-6 bg-dark-border mx-2" />
              <a
                href="https://youtube.com/@WEvidalFF"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-neon-red/10 border border-neon-red/30 rounded text-neon-red text-sm font-medium hover:bg-neon-red/20 transition-all"
              >
                <YoutubeIcon size={16} />
                <span className="hidden lg:inline">YouTube</span>
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 text-gray-300 hover:text-neon-red transition-colors"
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        <div className={`md:hidden mobile-menu ${
          isOpen 
            ? 'max-h-96 opacity-100' 
            : 'max-h-0 opacity-0 overflow-hidden'
        } bg-dark-bg/98 backdrop-blur-lg border-b border-neon-red/20`}>
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-4 py-3 text-gray-300 hover:text-neon-red hover:bg-neon-red/5 rounded transition-colors font-medium"
              >
                {link.label}
              </a>
            ))}
            <a
              href="https://youtube.com/@WEvidalFF"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-3 text-neon-red font-medium"
            >
              <YoutubeIcon size={18} />
              Canal Principal
            </a>
          </div>
        </div>
      </nav>

      {/* Scroll to top */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-6 right-6 z-50 w-12 h-12 bg-neon-red rounded-full flex items-center justify-center text-white shadow-[0_0_20px_#ff004060] hover:shadow-[0_0_30px_#ff0040] transition-all duration-300 ${
          showTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        aria-label="Scroll to top"
      >
        <ChevronUp size={24} />
      </button>
    </>
  );
}

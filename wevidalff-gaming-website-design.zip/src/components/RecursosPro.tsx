import { useState } from 'react';
import { Copy, Check, Download, Cpu, Terminal, BookOpen, Smartphone, ChevronDown, ChevronUp } from 'lucide-react';

interface Command {
  id: number;
  title: string;
  description: string;
  code: string;
  category: string;
  difficulty: 'Fácil' | 'Medio' | 'Avanzado';
}

interface OptGuide {
  id: number;
  title: string;
  steps: string[];
  category: string;
}

const commands: Command[] = [
  {
    id: 1,
    title: 'Dar Efecto de Velocidad Permanente',
    description: 'Otorga efecto de velocidad infinita al jugador más cercano.',
    code: '/effect @p speed 999999 255 true',
    category: 'Efectos',
    difficulty: 'Fácil'
  },
  {
    id: 2,
    title: 'Generar Relámpago en Coordenadas',
    description: 'Invoca un rayo en las coordenadas especificadas.',
    code: '/summon lightning_bolt ~5 ~ ~10',
    category: 'Entidades',
    difficulty: 'Fácil'
  },
  {
    id: 3,
    title: 'Crear Zona Protegida con Barrier',
    description: 'Genera una caja invisible de bloques barrier alrededor de una zona.',
    code: '/fill ~-10 ~-1 ~-10 ~10 ~10 ~10 barrier',
    category: 'Construcción',
    difficulty: 'Medio'
  },
  {
    id: 4,
    title: 'Dar Item Personalizado con NBT',
    description: 'Entrega una espada de diamante encantada con nombre personalizado.',
    code: '/give @p diamond_sword{display:{Name:\'[{"text":"Espada del Caos","color":"red","bold":true}]\'},Enchantments:[{id:sharpness,lvl:1000}]} 1',
    category: 'Items',
    difficulty: 'Avanzado'
  },
  {
    id: 5,
    title: 'Clonar Estructura Completa',
    description: 'Copia una estructura de un lugar a otro manteniendo los bloques.',
    code: '/clone 0 0 0 20 20 20 ~50 ~ ~ masked',
    category: 'Construcción',
    difficulty: 'Medio'
  },
  {
    id: 6,
    title: 'Establecer Bloque con Comando Condicional',
    description: 'Coloca un bloque de redstone si el jugador está en modo survival.',
    code: '/execute @p[m=survival] ~ ~ ~ setblock ~ ~ ~ redstone_block',
    category: 'Lógica',
    difficulty: 'Avanzado'
  },
  {
    id: 7,
    title: 'Titulo Épico en Pantalla',
    description: 'Muestra un título con estilo en la pantalla del jugador.',
    code: '/title @p title [{"text":"WEvidalFF","color":"#ff0040","bold":true}]',
    category: 'Visual',
    difficulty: 'Fácil'
  },
  {
    id: 8,
    title: 'Jugador Invisible con Partículas',
    description: 'Hace al jugador invisible pero genera partículas de fuego a su alrededor.',
    code: '/effect @p invisibility 999999 255 true\n/execute @p ~ ~ ~ particle minecraft:flame ~ ~1 ~',
    category: 'Efectos',
    difficulty: 'Medio'
  }
];

const optGuides: OptGuide[] = [
  {
    id: 1,
    title: '⚡ Optimizar Minecraft para Gama Baja',
    category: 'Rendimiento',
    steps: [
      'Ir a Configuración → Video → Render Distance: Mínimo (4 chunks)',
      'Desactivar "Smooth Lighting" y "Fancy Leaves"',
      'FPS: Fijar en 30 para estabilidad',
      'Desactivar "Show Sky" y "View Bobbing"',
      'Texturas: Usar pack de texturas 8x8 o 4x4',
      'Sonido: Reducir al 50% o desactivar',
      'Cerrar todas las apps en segundo plano antes de jugar'
    ]
  },
  {
    id: 2,
    title: '🎮 Optimizar Free Fire para Gama Baja',
    category: 'Rendimiento',
    steps: [
      'Ir a Configuración → Display → Graphics: "Low"',
      'High Resolution: Desactivar',
      'Shadow: Desactivar',
      'FPS: Configurar en "Normal"',
      'Minimap: Mantener activado pero sin rotación',
      'Descargar el pack de recursos de baja resolución desde la tienda',
      'Activar "Game Mode" o "Performance Mode" en ajustes del teléfono',
      'Limpiar caché del juego semanalmente'
    ]
  },
  {
    id: 3,
    title: '📱 Liberar RAM en Android',
    category: 'Sistema',
    steps: [
      'Ir a Ajustes → Aplicaciones → Forzar cierre de apps no usadas',
      'Desactivar animaciones: Opciones de Desarrollador → Escala de animación 0.5x',
      'Usar "Limpiar memoria" en el menú de aplicaciones recientes',
      'Desinstalar bloatware y apps innecesarias',
      'Desactivar "Background App Refresh" en apps que no necesites',
      'Reiniciar el teléfono antes de sesiones de gaming intensas'
    ]
  }
];

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium transition-all ${
        copied 
          ? 'bg-minecraft-green/20 text-minecraft-green' 
          : 'bg-dark-surface text-gray-400 hover:text-white'
      }`}
    >
      {copied ? <Check size={10} /> : <Copy size={10} />}
      {copied ? 'Copiado' : 'Copiar'}
    </button>
  );
}

function DifficultyBadge({ difficulty }: { difficulty: string }) {
  const colors: Record<string, string> = {
    'Fácil': 'bg-minecraft-green/20 text-minecraft-green border-minecraft-green/30',
    'Medio': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    'Avanzado': 'bg-neon-red/20 text-neon-red border-neon-red/30',
  };

  return (
    <span className={`px-2 py-0.5 rounded text-[10px] font-medium border ${colors[difficulty]}`}>
      {difficulty}
    </span>
  );
}

export default function RecursosPro() {
  const [activeTab, setActiveTab] = useState<'commands' | 'guides'>('commands');
  const [expandedGuide, setExpandedGuide] = useState<number | null>(null);
  const [filterCategory, setFilterCategory] = useState('Todos');

  const commandCategories = ['Todos', ...new Set(commands.map(c => c.category))];
  const filteredCommands = filterCategory === 'Todos' 
    ? commands 
    : commands.filter(c => c.category === filterCategory);

  return (
    <section id="recursos" className="relative py-20 sm:py-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-dark-bg via-dark-surface to-dark-bg" />
      <div className="absolute inset-0 grid-bg opacity-20" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-minecraft-green/10 border border-minecraft-green/20 rounded-full text-minecraft-green text-xs font-medium mb-4">
            <Terminal size={12} />
            RECURSOS TÉCNICOS
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-4xl md:text-5xl mb-4">
            <span className="text-white">RECURSOS</span>{' '}
            <span className="text-minecraft-green">PRO</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto">
            Comandos técnicos para Minecraft Bedrock y guías de optimización para dispositivos de gama baja.
          </p>
          <div className="red-line w-24 mx-auto mt-4" />
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-dark-card border border-dark-border rounded-lg p-1 inline-flex">
            <button
              onClick={() => setActiveTab('commands')}
              className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'commands'
                  ? 'bg-neon-red text-white shadow-[0_0_15px_#ff004040]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Terminal size={16} />
              <span className="hidden sm:inline">Comandos</span> MC
            </button>
            <button
              onClick={() => setActiveTab('guides')}
              className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'guides'
                  ? 'bg-neon-red text-white shadow-[0_0_15px_#ff004040]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Smartphone size={16} />
              <span className="hidden sm:inline">Guías de</span> Optimización
            </button>
          </div>
        </div>

        {/* Commands Tab */}
        {activeTab === 'commands' && (
          <div>
            {/* Command categories */}
            <div className="flex flex-wrap justify-center gap-2 mb-6">
              {commandCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterCategory(cat)}
                  className={`px-3 py-1.5 rounded-md text-[11px] font-medium transition-all ${
                    filterCategory === cat
                      ? 'bg-minecraft-green/20 text-minecraft-green border border-minecraft-green/30'
                      : 'bg-dark-card border border-dark-border text-gray-500 hover:text-gray-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="space-y-4">
              {filteredCommands.map((cmd) => (
                <div key={cmd.id} className="bg-dark-card border border-dark-border rounded-xl p-4 sm:p-5 card-hover">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-3">
                    <div>
                      <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
                        <Cpu size={14} className="text-minecraft-green" />
                        {cmd.title}
                      </h3>
                      <p className="text-gray-500 text-xs mt-1">{cmd.description}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="px-2 py-0.5 bg-dark-surface rounded text-[10px] text-gray-500 border border-dark-border">
                        {cmd.category}
                      </span>
                      <DifficultyBadge difficulty={cmd.difficulty} />
                    </div>
                  </div>

                  {/* Code block */}
                  <div className="code-block rounded-lg p-3 sm:p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] text-gray-600 font-mono">bedrock-command</span>
                      <CopyButton text={cmd.code} />
                    </div>
                    <pre className="text-minecraft-green text-xs sm:text-sm font-mono overflow-x-auto whitespace-pre">
                      <code>{cmd.code}</code>
                    </pre>
                  </div>
                </div>
              ))}
            </div>

            {/* Download section */}
            <div className="mt-8 bg-dark-card border border-neon-red/20 rounded-xl p-6 text-center">
              <BookOpen size={32} className="text-neon-red mx-auto mb-3" />
              <h3 className="font-heading font-bold text-lg mb-2">Pack de Comandos Completo</h3>
              <p className="text-gray-400 text-sm mb-4">
                Descarga todos los comandos en un archivo .mcfunction listo para usar.
              </p>
              <button className="inline-flex items-center gap-2 px-6 py-3 bg-neon-red text-white font-bold rounded-lg text-sm hover:shadow-[0_0_20px_#ff004060] transition-all active:scale-95">
                <Download size={16} />
                Descargar Pack (.zip)
              </button>
            </div>
          </div>
        )}

        {/* Guides Tab */}
        {activeTab === 'guides' && (
          <div className="space-y-4">
            {optGuides.map((guide) => (
              <div
                key={guide.id}
                className="bg-dark-card border border-dark-border rounded-xl overflow-hidden card-hover"
              >
                <button
                  onClick={() => setExpandedGuide(expandedGuide === guide.id ? null : guide.id)}
                  className="w-full flex items-center justify-between p-4 sm:p-5 text-left"
                >
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{guide.title.split(' ')[0]}</div>
                    <div>
                      <h3 className="font-heading font-bold text-sm text-white">{guide.title.substring(guide.title.indexOf(' ') + 1)}</h3>
                      <span className="text-[10px] text-gray-500 uppercase">{guide.category}</span>
                    </div>
                  </div>
                  {expandedGuide === guide.id ? (
                    <ChevronUp size={18} className="text-neon-red shrink-0" />
                  ) : (
                    <ChevronDown size={18} className="text-gray-500 shrink-0" />
                  )}
                </button>

                {expandedGuide === guide.id && (
                  <div className="px-4 sm:px-5 pb-5 fade-in-up">
                    <div className="border-t border-dark-border pt-4">
                      <ol className="space-y-3">
                        {guide.steps.map((step, i) => (
                          <li key={i} className="flex gap-3">
                            <span className="shrink-0 w-6 h-6 bg-neon-red/10 border border-neon-red/30 rounded flex items-center justify-center text-neon-red text-xs font-bold">
                              {i + 1}
                            </span>
                            <p className="text-gray-300 text-sm leading-relaxed">{step}</p>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Extra tip card */}
            <div className="bg-gradient-to-r from-neon-red/10 to-dark-card border border-neon-red/20 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <Smartphone size={24} className="text-neon-red shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-heading font-bold text-sm mb-1">💡 Tip Pro de WEvidalFF</h4>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Para grabar con calidad en gama baja, usa <span className="text-white font-semibold">Casco Pro</span> con 
                    configuración de grabación a 720p/30fps. Esto reduce la carga en el procesador mientras 
                    mantienes una calidad profesional para tus videos.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

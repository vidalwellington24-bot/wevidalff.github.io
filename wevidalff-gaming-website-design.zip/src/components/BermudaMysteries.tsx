import { useState } from 'react';
import { Eye, Clock, Flame, ChevronRight, MessageCircle } from 'lucide-react';

interface MysteryPost {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  views: string;
  hot: boolean;
  emoji: string;
  content: string;
}

const mysteries: MysteryPost[] = [
  {
    id: 1,
    title: 'El Monstruo de Bermuda: ¿Mito o Realidad?',
    excerpt: 'Análisis profundo de la criatura más misteriosa que acecha las aguas del mapa Bermuda en Free Fire. Evidencias, teorías y la verdad detrás del mito.',
    category: 'Teoría',
    readTime: '8 min',
    views: '45.2K',
    hot: true,
    emoji: '🐙',
    content: 'En las profundidades del mapa Bermuda, existe una criatura que pocos han visto pero muchos temen. Según los datos del juego, hay zonas del mapa donde los sonidos ambientales cambian drásticamente, sugiriendo la presencia de algo enorme bajo el agua. ¿Es un Easter egg de Garena o algo más?'
  },
  {
    id: 2,
    title: 'El Búnker Secreto de Pochinok',
    excerpt: 'Descubre el búnker oculto que pocos conocen bajo la zona de Pochinok. Coordendas exactas y método de acceso revelado.',
    category: 'Secreto',
    readTime: '5 min',
    views: '32.1K',
    hot: true,
    emoji: '🏗️',
    content: 'Pochinok siempre ha sido una zona tranquila del mapa, pero bajo sus edificios existe un sistema de túneles que conecta con puntos estratégicos. En este artículo te muestro las coordenadas exactas y cómo acceder a este espacio oculto.'
  },
  {
    id: 3,
    title: 'Laboratorio Omega: El Experimento Fallido',
    excerpt: 'La historia no contada del Laboratorio Omega y los experimentos que crearon las zonas de radiación del mapa Bermuda.',
    category: 'Lore',
    readTime: '12 min',
    views: '28.7K',
    hot: false,
    emoji: '⚗️',
    content: 'El Laboratorio Omega no es solo un punto más en el mapa. Tiene una historia profunda que conecta con los orígenes del juego. Los contenedores tóxicos, las computadoras abandonadas y los equipos de protección no están ahí por casualidad.'
  },
  {
    id: 4,
    title: ' Fantasmas del Clock Tower: Medianoche',
    excerpt: '¿Qué sucede en la Torre del Reloj exactamente a las 12:00 AM? Fenómenos paranormales documentados en Free Fire.',
    category: 'Paranormal',
    readTime: '6 min',
    views: '51.3K',
    hot: true,
    emoji: '👻',
    content: 'La Clock Tower de Bermuda esconde secretos que solo se revelan en condiciones muy específicas. Jugadores reportan sonidos inexplicables, sombras que aparecen en las pantallas y coordenadas que cambian misteriosamente a medianoche.'
  },
  {
    id: 5,
    title: 'El Mensaje Cifrado de Hangar',
    excerpt: 'Descifrando el código oculto en las paredes del Hangar que revela coordenadas de un punto secreto del mapa.',
    category: 'Código',
    readTime: '7 min',
    views: '19.8K',
    hot: false,
    emoji: '🔐',
    content: 'Si observas con detenimiento las paredes del Hangar, encontrarás una serie de números y símbolos que parecen aleatorios. Pero cuando los aplicas como coordenadas en el mapa, revelan algo que Garena nunca quiso que encontráramos.'
  },
  {
    id: 6,
    title: 'Teoría: Bermuda es una Isla Artificial',
    excerpt: 'Evidencias que sugieren que todo el mapa de Bermuda fue construido artificialmente como un experimento social.',
    category: 'Teoría',
    readTime: '10 min',
    views: '38.5K',
    hot: false,
    emoji: '🏝️',
    content: 'Los bordes del mapa, la distribución perfecta de las zonas, los edificios estratégicamente colocados... Todo apunta a que Bermuda no es una isla natural sino un experimento diseñado con un propósito específico.'
  }
];

const categories = ['Todos', 'Teoría', 'Secreto', 'Lore', 'Paranormal', 'Código'];

export default function BermudaMysteries() {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [expandedPost, setExpandedPost] = useState<number | null>(null);

  const filtered = selectedCategory === 'Todos' 
    ? mysteries 
    : mysteries.filter(m => m.category === selectedCategory);

  return (
    <section id="misterios" className="relative py-20 sm:py-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark-bg" />
      <div className="absolute inset-0 grid-bg opacity-20" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-bermuda-teal/10 border border-bermuda-teal/20 rounded-full text-bermuda-teal text-xs font-medium mb-4">
            🌊 BLOG DE INVESTIGACIÓN
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-4xl md:text-5xl mb-4">
            <span className="text-white">MISTERIOS DE</span>{' '}
            <span className="text-neon-red neon-text-subtle">BERMUDA</span>
          </h2>
          <p className="text-gray-400 text-sm max-w-lg mx-auto">
            Teorías, secretos y leyendas oscuras del mundo de Free Fire. ¿Estás listo para descubrir la verdad?
          </p>
          <div className="red-line w-24 mx-auto mt-4" />
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-neon-red text-white shadow-[0_0_15px_#ff004040]'
                  : 'bg-dark-card border border-dark-border text-gray-400 hover:border-neon-red/30 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Mystery cards grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((post) => (
            <article
              key={post.id}
              className={`group bg-dark-card border rounded-xl overflow-hidden card-hover cursor-pointer ${
                expandedPost === post.id ? 'border-neon-red' : 'border-dark-border'
              }`}
              onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
            >
              {/* Card image area */}
              <div className="relative h-36 bg-gradient-to-br from-dark-surface to-dark-bg overflow-hidden">
                <img 
                  src="/images/bermuda-mystery.jpg" 
                  alt=""
                  className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-opacity"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-card to-transparent" />
                
                {/* Emoji overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-5xl opacity-80 group-hover:scale-110 transition-transform">
                    {post.emoji}
                  </span>
                </div>

                {/* Hot badge */}
                {post.hot && (
                  <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-0.5 bg-neon-red/90 rounded text-[10px] font-bold text-white">
                    <Flame size={10} />
                    HOT
                  </div>
                )}

                {/* Category badge */}
                <div className="absolute top-2 left-2 px-2 py-0.5 bg-dark-bg/80 border border-neon-red/30 rounded text-[10px] text-neon-red font-medium">
                  {post.category}
                </div>
              </div>

              {/* Card content */}
              <div className="p-4">
                <h3 className="font-heading font-bold text-sm mb-2 text-white group-hover:text-neon-red transition-colors line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed mb-3 line-clamp-2">
                  {post.excerpt}
                </p>

                {/* Expanded content */}
                {expandedPost === post.id && (
                  <div className="mb-3 pb-3 border-b border-dark-border fade-in-up">
                    <p className="text-gray-400 text-xs leading-relaxed">
                      {post.content}
                    </p>
                  </div>
                )}

                {/* Meta */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-gray-600 text-[10px]">
                    <span className="flex items-center gap-1">
                      <Eye size={10} />
                      {post.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={10} />
                      {post.readTime}
                    </span>
                  </div>
                  <ChevronRight size={14} className={`text-neon-red transition-transform ${
                    expandedPost === post.id ? 'rotate-90' : ''
                  }`} />
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10">
          <a
            href="https://youtube.com/@WEvidalFF"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-neon-red/10 border border-neon-red/30 rounded-lg text-neon-red text-sm font-medium hover:bg-neon-red/20 transition-all"
          >
            <MessageCircle size={16} />
            Ver más misterios en YouTube
          </a>
        </div>
      </div>
    </section>
  );
}

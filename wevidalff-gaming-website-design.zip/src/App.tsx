import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Achievement from './components/Achievement';
import BermudaMysteries from './components/BermudaMysteries';
import RecursosPro from './components/RecursosPro';
import Debate from './components/Debate';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <Navbar />
      <Hero />
      
      {/* Decorative separator */}
      <div className="relative h-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-red/5 to-transparent" />
        <div className="red-line w-full" />
      </div>

      <Achievement />

      {/* Decorative separator */}
      <div className="relative h-12 overflow-hidden">
        <div className="red-line w-full" />
      </div>

      <BermudaMysteries />

      {/* Decorative separator */}
      <div className="relative h-12 overflow-hidden">
        <div className="red-line w-full" />
      </div>

      <RecursosPro />

      {/* Decorative separator */}
      <div className="relative h-12 overflow-hidden">
        <div className="red-line w-full" />
      </div>

      <Debate />

      <Footer />
    </div>
  );
}
